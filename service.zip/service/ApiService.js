'use strict';


/**
 * campaign
 * キャンペーン/広告
 *
 * returns List
 **/
exports.campaign = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "campaignImageURL" : "campaignImageURL",
  "campaignURL" : "campaignURL"
}, {
  "campaignImageURL" : "campaignImageURL",
  "campaignURL" : "campaignURL"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * checkout
 * チェックアウト（PunchOutOrderMessage）
 *
 * body CheckOutRequest チェックアウト（PunchOutOrderMessage）・リクエスト
 * returns CheckOutResult
 **/
exports.checkout = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "postUrl" : "postUrl",
  "orderMessageParamValue" : "orderMessageParamValue",
  "orderMessageParamName" : "orderMessageParamName"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * detailBG
 * バックグランドサーチ-商品詳細
 *
 * body DetailBGRequest バックグランドサーチ-商品詳細・リクエスト
 * no response value expected for this operation
 **/
exports.detailBG = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * favoriteAdd
 * お気に入り追加
 *
 * body FavoriteAddRequest お気に入り追加・リクエスト
 * returns List
 **/
exports.favoriteAdd = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "statusCode" : "statusCode"
}, {
  "statusCode" : "statusCode"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * favoriteDel
 * お気に入り削除
 *
 * body FavoriteDelRequest お気に入り削除・リクエスト
 * returns List
 **/
exports.favoriteDel = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "statusCode" : "statusCode"
}, {
  "statusCode" : "statusCode"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * favoriteSearch
 * お気に入り一覧
 *
 * body FavoriteSearchRequest お気に入り一覧・リクエスト
 * no response value expected for this operation
 **/
exports.favoriteSearch = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * getChildCategoryList
 * カテゴリファセット下位層取得
 *
 * body ChildCategoryListRequest カテゴリファセット下位層取得・リクエスト
 * returns List
 **/
exports.getChildCategoryList = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "childCategory" : [ {
    "childExist" : true,
    "hitCount" : 0,
    "openCheck" : true,
    "children" : [ "children", "children" ],
    "name" : "name",
    "id" : "id"
  }, {
    "childExist" : true,
    "hitCount" : 0,
    "openCheck" : true,
    "children" : [ "children", "children" ],
    "name" : "name",
    "id" : "id"
  } ]
}, {
  "childCategory" : [ {
    "childExist" : true,
    "hitCount" : 0,
    "openCheck" : true,
    "children" : [ "children", "children" ],
    "name" : "name",
    "id" : "id"
  }, {
    "childExist" : true,
    "hitCount" : 0,
    "openCheck" : true,
    "children" : [ "children", "children" ],
    "name" : "name",
    "id" : "id"
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * getChildMakerList
 * メーカーファセット下位層取得
 *
 * body ChildMakerListRequest メーカファセット下位層取得・リクエスト
 * returns List
 **/
exports.getChildMakerList = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "childMaker" : [ {
    "childExist" : true,
    "hitCount" : 0,
    "openCheck" : true,
    "children" : [ "children", "children" ],
    "name" : "name",
    "id" : "id"
  }, {
    "childExist" : true,
    "hitCount" : 0,
    "openCheck" : true,
    "children" : [ "children", "children" ],
    "name" : "name",
    "id" : "id"
  } ]
}, {
  "childMaker" : [ {
    "childExist" : true,
    "hitCount" : 0,
    "openCheck" : true,
    "children" : [ "children", "children" ],
    "name" : "name",
    "id" : "id"
  }, {
    "childExist" : true,
    "hitCount" : 0,
    "openCheck" : true,
    "children" : [ "children", "children" ],
    "name" : "name",
    "id" : "id"
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * getDetailFromCatalogById
 * idでカタログから商品詳細情報取得
 *
 * body DetailRequest idでカタログから商品詳細情報取得・リクエスト
 * returns DetailResult
 **/
exports.getDetailFromCatalogById = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "standard" : "standard",
  "itemInfo12Title" : "itemInfo12Title",
  "buyerCompanyCode" : "buyerCompanyCode",
  "itemInfo9Title" : "itemInfo9Title",
  "itemInfo12" : "itemInfo12",
  "itemInfo11" : "itemInfo11",
  "openPriceF" : "openPriceF",
  "itemInfo3Title" : "itemInfo3Title",
  "itemInfo10" : "itemInfo10",
  "ecoFlg" : 9,
  "buyerBuyingPrice" : 2,
  "campainFlg" : 2,
  "bgsF" : "bgsF",
  "ucd" : "ucd",
  "senderPrice" : 6,
  "catalogRelationName" : "catalogRelationName",
  "id" : "id",
  "itemInfo4Title" : "itemInfo4Title",
  "makerName" : "makerName",
  "goodsName" : "goodsName",
  "productInfoFlg" : "productInfoFlg",
  "deliveryTypeF" : "deliveryTypeF",
  "cpEndDate" : "cpEndDate",
  "casInfo" : "casInfo",
  "enterNumber" : 5,
  "imageRefF" : "imageRefF",
  "amountInfo" : "amountInfo",
  "itemInfo2Title" : "itemInfo2Title",
  "itemInfo10Title" : "itemInfo10Title",
  "itemInfo8Title" : "itemInfo8Title",
  "sClassifiedName" : "sClassifiedName",
  "itemInfo5Title" : "itemInfo5Title",
  "middleCalssName" : "middleCalssName",
  "buyerHopePrice" : 5,
  "countPurchase" : 3,
  "saleUnitName" : "saleUnitName",
  "favoriteFlg" : "favoriteFlg",
  "favariteDispFlag" : "favariteDispFlag",
  "origin" : "origin",
  "salesAgency" : "salesAgency",
  "supplyCompanyCode" : "supplyCompanyCode",
  "itemInfo6Title" : "itemInfo6Title",
  "itemInfo8" : "itemInfo8",
  "itemInfo7" : "itemInfo7",
  "cpStartDate" : "cpStartDate",
  "itemInfo6" : "itemInfo6",
  "designatedDayDelivery" : "designatedDayDelivery",
  "rcd" : "rcd",
  "itemInfo5" : "itemInfo5",
  "itemInfo4" : "itemInfo4",
  "itemInfo3" : "itemInfo3",
  "itemInfo2" : "itemInfo2",
  "brand2Name" : "brand2Name",
  "itemInfo1" : "itemInfo1",
  "brand3Name" : "brand3Name",
  "supplyBranchCode" : "supplyBranchCode",
  "catalogRelationId" : "catalogRelationId",
  "itemInfo7Title" : "itemInfo7Title",
  "itemInfo9" : "itemInfo9",
  "greenFlg" : 7,
  "brand1Name" : "brand1Name",
  "lastestPurchaseDate" : "2000-01-23",
  "itemInfo1Title" : "itemInfo1Title",
  "itemInfo11Title" : "itemInfo11Title",
  "standardPrice" : 1,
  "buyerBranchCode" : "buyerBranchCode",
  "categoryCode" : "categoryCode",
  "lClassifiedName" : "lClassifiedName",
  "url" : "url",
  "mClassifiedName" : "mClassifiedName",
  "indexTypeF" : 0,
  "enterNumberName" : "enterNumberName",
  "goodsCategoryName" : "goodsCategoryName",
  "goodsCode" : "goodsCode"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * getDetailFromCatalogByUcd
 * ucdでカタログから商品詳細情報取得
 *
 * body DetailUcdRequest ucdでカタログから商品詳細情報取得・リクエスト
 * returns DetailUcd
 **/
exports.getDetailFromCatalogByUcd = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "standard" : "standard",
  "itemInfo12Title" : "itemInfo12Title",
  "buyerCompanyCode" : "buyerCompanyCode",
  "itemInfo9Title" : "itemInfo9Title",
  "itemInfo12" : "itemInfo12",
  "itemInfo11" : "itemInfo11",
  "openPriceF" : "openPriceF",
  "itemInfo3Title" : "itemInfo3Title",
  "itemInfo10" : "itemInfo10",
  "ecoFlg" : 9,
  "buyerBuyingPrice" : 2,
  "campainFlg" : 2,
  "bgsF" : "bgsF",
  "ucd" : "ucd",
  "senderPrice" : 6,
  "catalogRelationName" : "catalogRelationName",
  "id" : "id",
  "itemInfo4Title" : "itemInfo4Title",
  "makerName" : "makerName",
  "goodsName" : "goodsName",
  "productInfoFlg" : "productInfoFlg",
  "deliveryTypeF" : "deliveryTypeF",
  "cpEndDate" : "cpEndDate",
  "casInfo" : "casInfo",
  "enterNumber" : 5,
  "imageRefF" : "imageRefF",
  "amountInfo" : "amountInfo",
  "itemInfo2Title" : "itemInfo2Title",
  "itemInfo10Title" : "itemInfo10Title",
  "itemInfo8Title" : "itemInfo8Title",
  "sClassifiedName" : "sClassifiedName",
  "itemInfo5Title" : "itemInfo5Title",
  "middleCalssName" : "middleCalssName",
  "buyerHopePrice" : 5,
  "countPurchase" : 3,
  "saleUnitName" : "saleUnitName",
  "favoriteFlg" : "favoriteFlg",
  "favariteDispFlag" : "favariteDispFlag",
  "origin" : "origin",
  "salesAgency" : "salesAgency",
  "supplyCompanyCode" : "supplyCompanyCode",
  "itemInfo6Title" : "itemInfo6Title",
  "itemInfo8" : "itemInfo8",
  "itemInfo7" : "itemInfo7",
  "cpStartDate" : "cpStartDate",
  "itemInfo6" : "itemInfo6",
  "designatedDayDelivery" : "designatedDayDelivery",
  "rcd" : "rcd",
  "itemInfo5" : "itemInfo5",
  "itemInfo4" : "itemInfo4",
  "itemInfo3" : "itemInfo3",
  "itemInfo2" : "itemInfo2",
  "brand2Name" : "brand2Name",
  "itemInfo1" : "itemInfo1",
  "brand3Name" : "brand3Name",
  "supplyBranchCode" : "supplyBranchCode",
  "catalogRelationId" : "catalogRelationId",
  "itemInfo7Title" : "itemInfo7Title",
  "itemInfo9" : "itemInfo9",
  "greenFlg" : 7,
  "brand1Name" : "brand1Name",
  "lastestPurchaseDate" : "2000-01-23",
  "itemInfo1Title" : "itemInfo1Title",
  "itemInfo11Title" : "itemInfo11Title",
  "standardPrice" : 1,
  "buyerBranchCode" : "buyerBranchCode",
  "categoryCode" : "categoryCode",
  "lClassifiedName" : "lClassifiedName",
  "url" : "url",
  "mClassifiedName" : "mClassifiedName",
  "indexTypeF" : 0,
  "enterNumberName" : "enterNumberName",
  "goodsCategoryName" : "goodsCategoryName",
  "goodsCode" : "goodsCode"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * getDetailFromTranzById
 * idで購買履歴から商品詳細情報取得
 *
 * body DetailTranzRequest idで購買履歴から商品詳細情報取得・リクエスト
 * returns DetailTranz
 **/
exports.getDetailFromTranzById = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "standard" : "standard",
  "itemInfo12Title" : "itemInfo12Title",
  "buyerCompanyCode" : "buyerCompanyCode",
  "itemInfo9Title" : "itemInfo9Title",
  "itemInfo12" : "itemInfo12",
  "itemInfo11" : "itemInfo11",
  "openPriceF" : "openPriceF",
  "itemInfo3Title" : "itemInfo3Title",
  "itemInfo10" : "itemInfo10",
  "ecoFlg" : 9,
  "buyerBuyingPrice" : 2,
  "campainFlg" : 2,
  "bgsF" : "bgsF",
  "ucd" : "ucd",
  "senderPrice" : 6,
  "catalogRelationName" : "catalogRelationName",
  "id" : "id",
  "itemInfo4Title" : "itemInfo4Title",
  "makerName" : "makerName",
  "goodsName" : "goodsName",
  "productInfoFlg" : "productInfoFlg",
  "deliveryTypeF" : "deliveryTypeF",
  "cpEndDate" : "cpEndDate",
  "casInfo" : "casInfo",
  "enterNumber" : 5,
  "imageRefF" : "imageRefF",
  "amountInfo" : "amountInfo",
  "itemInfo2Title" : "itemInfo2Title",
  "itemInfo10Title" : "itemInfo10Title",
  "itemInfo8Title" : "itemInfo8Title",
  "sClassifiedName" : "sClassifiedName",
  "itemInfo5Title" : "itemInfo5Title",
  "middleCalssName" : "middleCalssName",
  "buyerHopePrice" : 5,
  "countPurchase" : 3,
  "saleUnitName" : "saleUnitName",
  "favoriteFlg" : "favoriteFlg",
  "favariteDispFlag" : "favariteDispFlag",
  "origin" : "origin",
  "salesAgency" : "salesAgency",
  "supplyCompanyCode" : "supplyCompanyCode",
  "itemInfo6Title" : "itemInfo6Title",
  "itemInfo8" : "itemInfo8",
  "itemInfo7" : "itemInfo7",
  "cpStartDate" : "cpStartDate",
  "itemInfo6" : "itemInfo6",
  "designatedDayDelivery" : "designatedDayDelivery",
  "rcd" : "rcd",
  "itemInfo5" : "itemInfo5",
  "itemInfo4" : "itemInfo4",
  "itemInfo3" : "itemInfo3",
  "itemInfo2" : "itemInfo2",
  "brand2Name" : "brand2Name",
  "itemInfo1" : "itemInfo1",
  "brand3Name" : "brand3Name",
  "supplyBranchCode" : "supplyBranchCode",
  "catalogRelationId" : "catalogRelationId",
  "itemInfo7Title" : "itemInfo7Title",
  "itemInfo9" : "itemInfo9",
  "greenFlg" : 7,
  "brand1Name" : "brand1Name",
  "lastestPurchaseDate" : "2000-01-23",
  "itemInfo1Title" : "itemInfo1Title",
  "itemInfo11Title" : "itemInfo11Title",
  "standardPrice" : 1,
  "buyerBranchCode" : "buyerBranchCode",
  "categoryCode" : "categoryCode",
  "lClassifiedName" : "lClassifiedName",
  "url" : "url",
  "mClassifiedName" : "mClassifiedName",
  "indexTypeF" : 0,
  "enterNumberName" : "enterNumberName",
  "goodsCategoryName" : "goodsCategoryName",
  "goodsCode" : "goodsCode"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * getDetailFromTranzByReferenceKey
 * referenceKeyで購買履歴から商品詳細情報取得
 *
 * body DetailReferenceKeyRequest referenceKeyで購買履歴から商品詳細情報取得・リクエスト
 * returns DetailReferenceKey
 **/
exports.getDetailFromTranzByReferenceKey = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "searchIdList" : [ "searchIdList", "searchIdList" ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * getFileContent
 * お知らせ・キャンペーン・広告
 *
 * body Blank ブランクリクエスト：{}
 * returns Infomation
 **/
exports.getFileContent = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "ad" : "ad",
  "cp" : "cp",
  "info" : "info"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * GetProductImage
 * 商品画像imageタグ取得
 *
 * body GetImageTagRequest 商品画像imageタグ取得・リクエスト
 * returns GetImageTagResult
 **/
exports.getProductImage = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "responseBody" : "responseBody",
  "statusCode" : "statusCode"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * getSearchBGResult
 * バックグランドサーチ-結果取得
 *
 * body BackGroundSearchResultRequest バックグランドサーチ-結果取得リクエスト
 * no response value expected for this operation
 **/
exports.getSearchBGResult = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * getUserInfo
 * 
 *
 * body Blank ブランクリクエスト：{}
 * returns UserInfo
 **/
exports.getUserInfo = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "buyerCompanyCode" : "buyerCompanyCode",
  "buyerBranchCode" : "buyerBranchCode",
  "buyerCompanyName" : "buyerCompanyName",
  "userName" : "userName",
  "userId" : "userId",
  "buyerBranchName" : "buyerBranchName"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * latestPurchase
 * 最近購入した商品
 *
 * returns List
 **/
exports.latestPurchase = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "indexTypeF" : 0,
  "ucd" : "ucd",
  "lastestPurchaseDate" : "2000-01-23",
  "goodsImageURL" : "goodsImageURL",
  "salesAgency" : "salesAgency",
  "senderPrice" : 6,
  "id" : "id",
  "goodsName" : "goodsName"
}, {
  "indexTypeF" : 0,
  "ucd" : "ucd",
  "lastestPurchaseDate" : "2000-01-23",
  "goodsImageURL" : "goodsImageURL",
  "salesAgency" : "salesAgency",
  "senderPrice" : 6,
  "id" : "id",
  "goodsName" : "goodsName"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * oftenPurchase
 * よく購入する商品
 *
 * returns List
 **/
exports.oftenPurchase = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "indexTypeF" : 0,
  "ucd" : "ucd",
  "goodsImageURL" : "goodsImageURL",
  "salesAgency" : "salesAgency",
  "senderPrice" : 1,
  "id" : "id",
  "countPurchase" : 6,
  "goodsName" : "goodsName"
}, {
  "indexTypeF" : 0,
  "ucd" : "ucd",
  "goodsImageURL" : "goodsImageURL",
  "salesAgency" : "salesAgency",
  "senderPrice" : 1,
  "id" : "id",
  "countPurchase" : 6,
  "goodsName" : "goodsName"
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Search
 * 商品検索（カタログ：Solr Index）
 *
 * body SearchRequest 商品検索（カタログ：Solr Index）・リクエスト
 * returns SearchResult
 **/
exports.search = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "totalHitCount" : 0,
  "productList" : [ {
    "standard" : "standard",
    "itemInfo12Title" : "itemInfo12Title",
    "buyerCompanyCode" : "buyerCompanyCode",
    "itemInfo9Title" : "itemInfo9Title",
    "itemInfo12" : "itemInfo12",
    "itemInfo11" : "itemInfo11",
    "openPriceF" : "openPriceF",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo10" : "itemInfo10",
    "ecoFlg" : 9,
    "campainFlg" : 2,
    "bgsF" : "bgsF",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "deliveryTypeF" : "deliveryTypeF",
    "casInfo" : "casInfo",
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "amountInfo" : "amountInfo",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo10Title" : "itemInfo10Title",
    "itemInfo8Title" : "itemInfo8Title",
    "sClassifiedName" : "sClassifiedName",
    "itemInfo5Title" : "itemInfo5Title",
    "middleCalssName" : "middleCalssName",
    "buyerHopePrice" : 5,
    "countPurchase" : 3,
    "saleUnitName" : "saleUnitName",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo8" : "itemInfo8",
    "itemInfo7" : "itemInfo7",
    "itemInfo6" : "itemInfo6",
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "itemInfo5" : "itemInfo5",
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "brand2Name" : "brand2Name",
    "itemInfo1" : "itemInfo1",
    "brand3Name" : "brand3Name",
    "supplyBranchCode" : "supplyBranchCode",
    "catalogRelationId" : "catalogRelationId",
    "itemInfo7Title" : "itemInfo7Title",
    "itemInfo9" : "itemInfo9",
    "greenFlg" : 7,
    "brand1Name" : "brand1Name",
    "lastestPurchaseDate" : "2000-01-23",
    "itemInfo1Title" : "itemInfo1Title",
    "itemInfo11Title" : "itemInfo11Title",
    "standardPrice" : 5,
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "lClassifiedName" : "lClassifiedName",
    "url" : "url",
    "mClassifiedName" : "mClassifiedName",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCategoryName" : "goodsCategoryName",
    "goodsCode" : "goodsCode"
  }, {
    "standard" : "standard",
    "itemInfo12Title" : "itemInfo12Title",
    "buyerCompanyCode" : "buyerCompanyCode",
    "itemInfo9Title" : "itemInfo9Title",
    "itemInfo12" : "itemInfo12",
    "itemInfo11" : "itemInfo11",
    "openPriceF" : "openPriceF",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo10" : "itemInfo10",
    "ecoFlg" : 9,
    "campainFlg" : 2,
    "bgsF" : "bgsF",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "deliveryTypeF" : "deliveryTypeF",
    "casInfo" : "casInfo",
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "amountInfo" : "amountInfo",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo10Title" : "itemInfo10Title",
    "itemInfo8Title" : "itemInfo8Title",
    "sClassifiedName" : "sClassifiedName",
    "itemInfo5Title" : "itemInfo5Title",
    "middleCalssName" : "middleCalssName",
    "buyerHopePrice" : 5,
    "countPurchase" : 3,
    "saleUnitName" : "saleUnitName",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo8" : "itemInfo8",
    "itemInfo7" : "itemInfo7",
    "itemInfo6" : "itemInfo6",
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "itemInfo5" : "itemInfo5",
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "brand2Name" : "brand2Name",
    "itemInfo1" : "itemInfo1",
    "brand3Name" : "brand3Name",
    "supplyBranchCode" : "supplyBranchCode",
    "catalogRelationId" : "catalogRelationId",
    "itemInfo7Title" : "itemInfo7Title",
    "itemInfo9" : "itemInfo9",
    "greenFlg" : 7,
    "brand1Name" : "brand1Name",
    "lastestPurchaseDate" : "2000-01-23",
    "itemInfo1Title" : "itemInfo1Title",
    "itemInfo11Title" : "itemInfo11Title",
    "standardPrice" : 5,
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "lClassifiedName" : "lClassifiedName",
    "url" : "url",
    "mClassifiedName" : "mClassifiedName",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCategoryName" : "goodsCategoryName",
    "goodsCode" : "goodsCode"
  } ],
  "facets" : {
    "facetPriceList" : [ {
      "childExist" : true,
      "hitCount" : 7,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 7,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ],
    "facetMakerList" : [ {
      "childExist" : true,
      "hitCount" : 4,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 4,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ],
    "facetFlagList" : [ {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ],
    "facetCategoryList" : [ {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ]
  }
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * searchBG
 * バックグランドサーチ-横断検索
 *
 * body BackGroundSearchRequest バックグランドサーチ-横断検索・リクエスト
 * no response value expected for this operation
 **/
exports.searchBG = function(body) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * SearchDidYouMean
 * もしかして商品検索
 *
 * body SearchDidYouMeanRequest もしかして商品検索・リクエスト
 * returns SearchDidYouMeanResult
 **/
exports.searchDidYouMean = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "totalHitCount" : 0,
  "productList" : [ {
    "standard" : "standard",
    "itemInfo12Title" : "itemInfo12Title",
    "buyerCompanyCode" : "buyerCompanyCode",
    "itemInfo9Title" : "itemInfo9Title",
    "itemInfo12" : "itemInfo12",
    "itemInfo11" : "itemInfo11",
    "openPriceF" : "openPriceF",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo10" : "itemInfo10",
    "ecoFlg" : 9,
    "campainFlg" : 2,
    "bgsF" : "bgsF",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "deliveryTypeF" : "deliveryTypeF",
    "casInfo" : "casInfo",
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "amountInfo" : "amountInfo",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo10Title" : "itemInfo10Title",
    "itemInfo8Title" : "itemInfo8Title",
    "sClassifiedName" : "sClassifiedName",
    "itemInfo5Title" : "itemInfo5Title",
    "middleCalssName" : "middleCalssName",
    "buyerHopePrice" : 5,
    "countPurchase" : 3,
    "saleUnitName" : "saleUnitName",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo8" : "itemInfo8",
    "itemInfo7" : "itemInfo7",
    "itemInfo6" : "itemInfo6",
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "itemInfo5" : "itemInfo5",
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "brand2Name" : "brand2Name",
    "itemInfo1" : "itemInfo1",
    "brand3Name" : "brand3Name",
    "supplyBranchCode" : "supplyBranchCode",
    "catalogRelationId" : "catalogRelationId",
    "itemInfo7Title" : "itemInfo7Title",
    "itemInfo9" : "itemInfo9",
    "greenFlg" : 7,
    "brand1Name" : "brand1Name",
    "lastestPurchaseDate" : "2000-01-23",
    "itemInfo1Title" : "itemInfo1Title",
    "itemInfo11Title" : "itemInfo11Title",
    "standardPrice" : 5,
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "lClassifiedName" : "lClassifiedName",
    "url" : "url",
    "mClassifiedName" : "mClassifiedName",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCategoryName" : "goodsCategoryName",
    "goodsCode" : "goodsCode"
  }, {
    "standard" : "standard",
    "itemInfo12Title" : "itemInfo12Title",
    "buyerCompanyCode" : "buyerCompanyCode",
    "itemInfo9Title" : "itemInfo9Title",
    "itemInfo12" : "itemInfo12",
    "itemInfo11" : "itemInfo11",
    "openPriceF" : "openPriceF",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo10" : "itemInfo10",
    "ecoFlg" : 9,
    "campainFlg" : 2,
    "bgsF" : "bgsF",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "deliveryTypeF" : "deliveryTypeF",
    "casInfo" : "casInfo",
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "amountInfo" : "amountInfo",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo10Title" : "itemInfo10Title",
    "itemInfo8Title" : "itemInfo8Title",
    "sClassifiedName" : "sClassifiedName",
    "itemInfo5Title" : "itemInfo5Title",
    "middleCalssName" : "middleCalssName",
    "buyerHopePrice" : 5,
    "countPurchase" : 3,
    "saleUnitName" : "saleUnitName",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo8" : "itemInfo8",
    "itemInfo7" : "itemInfo7",
    "itemInfo6" : "itemInfo6",
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "itemInfo5" : "itemInfo5",
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "brand2Name" : "brand2Name",
    "itemInfo1" : "itemInfo1",
    "brand3Name" : "brand3Name",
    "supplyBranchCode" : "supplyBranchCode",
    "catalogRelationId" : "catalogRelationId",
    "itemInfo7Title" : "itemInfo7Title",
    "itemInfo9" : "itemInfo9",
    "greenFlg" : 7,
    "brand1Name" : "brand1Name",
    "lastestPurchaseDate" : "2000-01-23",
    "itemInfo1Title" : "itemInfo1Title",
    "itemInfo11Title" : "itemInfo11Title",
    "standardPrice" : 5,
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "lClassifiedName" : "lClassifiedName",
    "url" : "url",
    "mClassifiedName" : "mClassifiedName",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCategoryName" : "goodsCategoryName",
    "goodsCode" : "goodsCode"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * SearchFacets
 * 商品検索（カタログ：Solr Index）ファセットのみ
 *
 * body SearchFacetsRequest 商品検索（カタログ：Solr Index）ファセットのみ・リクエスト
 * returns List
 **/
exports.searchFacets = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "facets" : {
    "facetPriceList" : [ {
      "childExist" : true,
      "hitCount" : 7,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 7,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ],
    "facetMakerList" : [ {
      "childExist" : true,
      "hitCount" : 4,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 4,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ],
    "facetFlagList" : [ {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ],
    "facetCategoryList" : [ {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ]
  }
}, {
  "facets" : {
    "facetPriceList" : [ {
      "childExist" : true,
      "hitCount" : 7,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 7,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ],
    "facetMakerList" : [ {
      "childExist" : true,
      "hitCount" : 4,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 4,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ],
    "facetFlagList" : [ {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ],
    "facetCategoryList" : [ {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    }, {
      "childExist" : true,
      "hitCount" : 1,
      "children" : [ "children", "children" ],
      "openCheck" : true,
      "name" : "name",
      "codeName" : "codeName",
      "id" : "id",
      "check" : true
    } ]
  }
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * searchHistory
 * 購買履歴検索（Solr Tranz Index）
 *
 * body HistoryRequest 購買履歴検索（Solr Tranz Index）・リクエスト
 * returns History
 **/
exports.searchHistory = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "totalHitCount" : 0,
  "productList" : [ {
    "saleUnitName" : "saleUnitName",
    "purchaseDate" : "2000-01-23",
    "buyerCompanyCode" : "buyerCompanyCode",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "openPriceF" : "openPriceF",
    "ecoFlg" : 9,
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "campainFlg" : 3,
    "cheakCompleteDate" : "2000-01-23",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "supplyBranchCode" : "supplyBranchCode",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "purchaseNumber" : "purchaseNumber",
    "referenceKey" : "referenceKey",
    "deliveryTypeF" : "deliveryTypeF",
    "greenFlg" : 7,
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "standardPrice" : 5,
    "amountInfo" : "amountInfo",
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "url" : "url",
    "goodsJanCode" : "goodsJanCode",
    "buyAmount" : 2,
    "detailNumber" : "detailNumber",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCode" : "goodsCode",
    "buyerHopePrice" : 5
  }, {
    "saleUnitName" : "saleUnitName",
    "purchaseDate" : "2000-01-23",
    "buyerCompanyCode" : "buyerCompanyCode",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "openPriceF" : "openPriceF",
    "ecoFlg" : 9,
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "campainFlg" : 3,
    "cheakCompleteDate" : "2000-01-23",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "supplyBranchCode" : "supplyBranchCode",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "purchaseNumber" : "purchaseNumber",
    "referenceKey" : "referenceKey",
    "deliveryTypeF" : "deliveryTypeF",
    "greenFlg" : 7,
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "standardPrice" : 5,
    "amountInfo" : "amountInfo",
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "url" : "url",
    "goodsJanCode" : "goodsJanCode",
    "buyAmount" : 2,
    "detailNumber" : "detailNumber",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCode" : "goodsCode",
    "buyerHopePrice" : 5
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * SearchMoreLikeThis
 * 類似商品検索（カタログ）
 *
 * body SearchMoreLikeThisRequest 類似商品検索（カタログ）・リクエスト
 * returns SearchMoreLikeThisResult
 **/
exports.searchMoreLikeThis = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "totalHitCount" : 0,
  "productList" : [ {
    "standard" : "standard",
    "itemInfo12Title" : "itemInfo12Title",
    "buyerCompanyCode" : "buyerCompanyCode",
    "itemInfo9Title" : "itemInfo9Title",
    "itemInfo12" : "itemInfo12",
    "itemInfo11" : "itemInfo11",
    "openPriceF" : "openPriceF",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo10" : "itemInfo10",
    "ecoFlg" : 9,
    "campainFlg" : 2,
    "bgsF" : "bgsF",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "deliveryTypeF" : "deliveryTypeF",
    "casInfo" : "casInfo",
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "amountInfo" : "amountInfo",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo10Title" : "itemInfo10Title",
    "itemInfo8Title" : "itemInfo8Title",
    "sClassifiedName" : "sClassifiedName",
    "itemInfo5Title" : "itemInfo5Title",
    "middleCalssName" : "middleCalssName",
    "buyerHopePrice" : 5,
    "countPurchase" : 3,
    "saleUnitName" : "saleUnitName",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo8" : "itemInfo8",
    "itemInfo7" : "itemInfo7",
    "itemInfo6" : "itemInfo6",
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "itemInfo5" : "itemInfo5",
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "brand2Name" : "brand2Name",
    "itemInfo1" : "itemInfo1",
    "brand3Name" : "brand3Name",
    "supplyBranchCode" : "supplyBranchCode",
    "catalogRelationId" : "catalogRelationId",
    "itemInfo7Title" : "itemInfo7Title",
    "itemInfo9" : "itemInfo9",
    "greenFlg" : 7,
    "brand1Name" : "brand1Name",
    "lastestPurchaseDate" : "2000-01-23",
    "itemInfo1Title" : "itemInfo1Title",
    "itemInfo11Title" : "itemInfo11Title",
    "standardPrice" : 5,
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "lClassifiedName" : "lClassifiedName",
    "url" : "url",
    "mClassifiedName" : "mClassifiedName",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCategoryName" : "goodsCategoryName",
    "goodsCode" : "goodsCode"
  }, {
    "standard" : "standard",
    "itemInfo12Title" : "itemInfo12Title",
    "buyerCompanyCode" : "buyerCompanyCode",
    "itemInfo9Title" : "itemInfo9Title",
    "itemInfo12" : "itemInfo12",
    "itemInfo11" : "itemInfo11",
    "openPriceF" : "openPriceF",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo10" : "itemInfo10",
    "ecoFlg" : 9,
    "campainFlg" : 2,
    "bgsF" : "bgsF",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "deliveryTypeF" : "deliveryTypeF",
    "casInfo" : "casInfo",
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "amountInfo" : "amountInfo",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo10Title" : "itemInfo10Title",
    "itemInfo8Title" : "itemInfo8Title",
    "sClassifiedName" : "sClassifiedName",
    "itemInfo5Title" : "itemInfo5Title",
    "middleCalssName" : "middleCalssName",
    "buyerHopePrice" : 5,
    "countPurchase" : 3,
    "saleUnitName" : "saleUnitName",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo8" : "itemInfo8",
    "itemInfo7" : "itemInfo7",
    "itemInfo6" : "itemInfo6",
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "itemInfo5" : "itemInfo5",
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "brand2Name" : "brand2Name",
    "itemInfo1" : "itemInfo1",
    "brand3Name" : "brand3Name",
    "supplyBranchCode" : "supplyBranchCode",
    "catalogRelationId" : "catalogRelationId",
    "itemInfo7Title" : "itemInfo7Title",
    "itemInfo9" : "itemInfo9",
    "greenFlg" : 7,
    "brand1Name" : "brand1Name",
    "lastestPurchaseDate" : "2000-01-23",
    "itemInfo1Title" : "itemInfo1Title",
    "itemInfo11Title" : "itemInfo11Title",
    "standardPrice" : 5,
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "lClassifiedName" : "lClassifiedName",
    "url" : "url",
    "mClassifiedName" : "mClassifiedName",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCategoryName" : "goodsCategoryName",
    "goodsCode" : "goodsCode"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * SearchMoreLikeThisForBGS
 * 類似商品検索（元商品がBGSの場合）
 *
 * body SearchMoreLikeThisForBGSRequest 類似商品検索（元商品がBGSの場合）・リクエスト
 * returns SearchMoreLikeThisForBGSResult
 **/
exports.searchMoreLikeThisForBGS = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "totalHitCount" : 0,
  "productList" : [ {
    "standard" : "standard",
    "favoriteFlg" : "favoriteFlg",
    "partnerCode" : "partnerCode",
    "favariteDispFlag" : "favariteDispFlag",
    "salesAgency" : "salesAgency",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo8" : "itemInfo8",
    "ecoFlg" : 5,
    "itemInfo7" : "itemInfo7",
    "cpStartDate" : "cpStartDate",
    "itemInfo6" : "itemInfo6",
    "itemInfo5" : "itemInfo5",
    "campainFlg" : 2,
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "bgsF" : "bgsF",
    "imageUrl" : "imageUrl",
    "senderPrice" : 6,
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "itemDescription" : "itemDescription",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "itemInfo7Title" : "itemInfo7Title",
    "makerCode" : "makerCode",
    "cpEndDate" : "cpEndDate",
    "casInfo" : "casInfo",
    "greenFlg" : 5,
    "brand1Name" : "brand1Name",
    "origin\"" : "origin\"",
    "standardPrice" : 1,
    "amountInfo" : "amountInfo",
    "url" : "url",
    "appropriateDate" : "appropriateDate",
    "goodsJanCode" : "goodsJanCode",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo8Title" : "itemInfo8Title",
    "indexTypeF" : 7,
    "goodsCategoryName" : "goodsCategoryName",
    "itemInfo5Title" : "itemInfo5Title",
    "goodsCode" : "goodsCode"
  }, {
    "standard" : "standard",
    "favoriteFlg" : "favoriteFlg",
    "partnerCode" : "partnerCode",
    "favariteDispFlag" : "favariteDispFlag",
    "salesAgency" : "salesAgency",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo8" : "itemInfo8",
    "ecoFlg" : 5,
    "itemInfo7" : "itemInfo7",
    "cpStartDate" : "cpStartDate",
    "itemInfo6" : "itemInfo6",
    "itemInfo5" : "itemInfo5",
    "campainFlg" : 2,
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "bgsF" : "bgsF",
    "imageUrl" : "imageUrl",
    "senderPrice" : 6,
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "itemDescription" : "itemDescription",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "itemInfo7Title" : "itemInfo7Title",
    "makerCode" : "makerCode",
    "cpEndDate" : "cpEndDate",
    "casInfo" : "casInfo",
    "greenFlg" : 5,
    "brand1Name" : "brand1Name",
    "origin\"" : "origin\"",
    "standardPrice" : 1,
    "amountInfo" : "amountInfo",
    "url" : "url",
    "appropriateDate" : "appropriateDate",
    "goodsJanCode" : "goodsJanCode",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo8Title" : "itemInfo8Title",
    "indexTypeF" : 7,
    "goodsCategoryName" : "goodsCategoryName",
    "itemInfo5Title" : "itemInfo5Title",
    "goodsCode" : "goodsCode"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * SearchProducts
 * 商品検索（カタログ：Solr Index）商品のみ
 *
 * body SearchProductsRequest 商品検索（カタログ：Solr Index）商品のみ・リクエスト
 * returns SearchProductsResult
 **/
exports.searchProducts = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "totalHitCount" : 0,
  "productList" : [ {
    "standard" : "standard",
    "itemInfo12Title" : "itemInfo12Title",
    "buyerCompanyCode" : "buyerCompanyCode",
    "itemInfo9Title" : "itemInfo9Title",
    "itemInfo12" : "itemInfo12",
    "itemInfo11" : "itemInfo11",
    "openPriceF" : "openPriceF",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo10" : "itemInfo10",
    "ecoFlg" : 9,
    "campainFlg" : 2,
    "bgsF" : "bgsF",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "deliveryTypeF" : "deliveryTypeF",
    "casInfo" : "casInfo",
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "amountInfo" : "amountInfo",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo10Title" : "itemInfo10Title",
    "itemInfo8Title" : "itemInfo8Title",
    "sClassifiedName" : "sClassifiedName",
    "itemInfo5Title" : "itemInfo5Title",
    "middleCalssName" : "middleCalssName",
    "buyerHopePrice" : 5,
    "countPurchase" : 3,
    "saleUnitName" : "saleUnitName",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo8" : "itemInfo8",
    "itemInfo7" : "itemInfo7",
    "itemInfo6" : "itemInfo6",
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "itemInfo5" : "itemInfo5",
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "brand2Name" : "brand2Name",
    "itemInfo1" : "itemInfo1",
    "brand3Name" : "brand3Name",
    "supplyBranchCode" : "supplyBranchCode",
    "catalogRelationId" : "catalogRelationId",
    "itemInfo7Title" : "itemInfo7Title",
    "itemInfo9" : "itemInfo9",
    "greenFlg" : 7,
    "brand1Name" : "brand1Name",
    "lastestPurchaseDate" : "2000-01-23",
    "itemInfo1Title" : "itemInfo1Title",
    "itemInfo11Title" : "itemInfo11Title",
    "standardPrice" : 5,
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "lClassifiedName" : "lClassifiedName",
    "url" : "url",
    "mClassifiedName" : "mClassifiedName",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCategoryName" : "goodsCategoryName",
    "goodsCode" : "goodsCode"
  }, {
    "standard" : "standard",
    "itemInfo12Title" : "itemInfo12Title",
    "buyerCompanyCode" : "buyerCompanyCode",
    "itemInfo9Title" : "itemInfo9Title",
    "itemInfo12" : "itemInfo12",
    "itemInfo11" : "itemInfo11",
    "openPriceF" : "openPriceF",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo10" : "itemInfo10",
    "ecoFlg" : 9,
    "campainFlg" : 2,
    "bgsF" : "bgsF",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "deliveryTypeF" : "deliveryTypeF",
    "casInfo" : "casInfo",
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "amountInfo" : "amountInfo",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo10Title" : "itemInfo10Title",
    "itemInfo8Title" : "itemInfo8Title",
    "sClassifiedName" : "sClassifiedName",
    "itemInfo5Title" : "itemInfo5Title",
    "middleCalssName" : "middleCalssName",
    "buyerHopePrice" : 5,
    "countPurchase" : 3,
    "saleUnitName" : "saleUnitName",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo8" : "itemInfo8",
    "itemInfo7" : "itemInfo7",
    "itemInfo6" : "itemInfo6",
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "itemInfo5" : "itemInfo5",
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "brand2Name" : "brand2Name",
    "itemInfo1" : "itemInfo1",
    "brand3Name" : "brand3Name",
    "supplyBranchCode" : "supplyBranchCode",
    "catalogRelationId" : "catalogRelationId",
    "itemInfo7Title" : "itemInfo7Title",
    "itemInfo9" : "itemInfo9",
    "greenFlg" : 7,
    "brand1Name" : "brand1Name",
    "lastestPurchaseDate" : "2000-01-23",
    "itemInfo1Title" : "itemInfo1Title",
    "itemInfo11Title" : "itemInfo11Title",
    "standardPrice" : 5,
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "lClassifiedName" : "lClassifiedName",
    "url" : "url",
    "mClassifiedName" : "mClassifiedName",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCategoryName" : "goodsCategoryName",
    "goodsCode" : "goodsCode"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * SearchRecommend
 * おすすめ商品
 *
 * body SearchRecommendRequest おすすめ商品・リクエスト
 * returns SearchRecommendResult
 **/
exports.searchRecommend = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "totalHitCount" : 0,
  "productList" : [ {
    "standard" : "standard",
    "itemInfo12Title" : "itemInfo12Title",
    "buyerCompanyCode" : "buyerCompanyCode",
    "itemInfo9Title" : "itemInfo9Title",
    "itemInfo12" : "itemInfo12",
    "itemInfo11" : "itemInfo11",
    "openPriceF" : "openPriceF",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo10" : "itemInfo10",
    "ecoFlg" : 9,
    "campainFlg" : 2,
    "bgsF" : "bgsF",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "deliveryTypeF" : "deliveryTypeF",
    "casInfo" : "casInfo",
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "amountInfo" : "amountInfo",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo10Title" : "itemInfo10Title",
    "itemInfo8Title" : "itemInfo8Title",
    "sClassifiedName" : "sClassifiedName",
    "itemInfo5Title" : "itemInfo5Title",
    "middleCalssName" : "middleCalssName",
    "buyerHopePrice" : 5,
    "countPurchase" : 3,
    "saleUnitName" : "saleUnitName",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo8" : "itemInfo8",
    "itemInfo7" : "itemInfo7",
    "itemInfo6" : "itemInfo6",
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "itemInfo5" : "itemInfo5",
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "brand2Name" : "brand2Name",
    "itemInfo1" : "itemInfo1",
    "brand3Name" : "brand3Name",
    "supplyBranchCode" : "supplyBranchCode",
    "catalogRelationId" : "catalogRelationId",
    "itemInfo7Title" : "itemInfo7Title",
    "itemInfo9" : "itemInfo9",
    "greenFlg" : 7,
    "brand1Name" : "brand1Name",
    "lastestPurchaseDate" : "2000-01-23",
    "itemInfo1Title" : "itemInfo1Title",
    "itemInfo11Title" : "itemInfo11Title",
    "standardPrice" : 5,
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "lClassifiedName" : "lClassifiedName",
    "url" : "url",
    "mClassifiedName" : "mClassifiedName",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCategoryName" : "goodsCategoryName",
    "goodsCode" : "goodsCode"
  }, {
    "standard" : "standard",
    "itemInfo12Title" : "itemInfo12Title",
    "buyerCompanyCode" : "buyerCompanyCode",
    "itemInfo9Title" : "itemInfo9Title",
    "itemInfo12" : "itemInfo12",
    "itemInfo11" : "itemInfo11",
    "openPriceF" : "openPriceF",
    "itemInfo3Title" : "itemInfo3Title",
    "itemInfo10" : "itemInfo10",
    "ecoFlg" : 9,
    "campainFlg" : 2,
    "bgsF" : "bgsF",
    "ucd" : "ucd",
    "senderPrice" : 1,
    "catalogRelationName" : "catalogRelationName",
    "id" : "id",
    "itemInfo4Title" : "itemInfo4Title",
    "makerName" : "makerName",
    "goodsName" : "goodsName",
    "productInfoFlg" : "productInfoFlg",
    "deliveryTypeF" : "deliveryTypeF",
    "casInfo" : "casInfo",
    "enterNumber" : 2,
    "imageRefF" : "imageRefF",
    "amountInfo" : "amountInfo",
    "itemInfo2Title" : "itemInfo2Title",
    "itemInfo10Title" : "itemInfo10Title",
    "itemInfo8Title" : "itemInfo8Title",
    "sClassifiedName" : "sClassifiedName",
    "itemInfo5Title" : "itemInfo5Title",
    "middleCalssName" : "middleCalssName",
    "buyerHopePrice" : 5,
    "countPurchase" : 3,
    "saleUnitName" : "saleUnitName",
    "origin" : "origin",
    "salesAgency" : "salesAgency",
    "supplyCompanyCode" : "supplyCompanyCode",
    "itemInfo6Title" : "itemInfo6Title",
    "itemInfo8" : "itemInfo8",
    "itemInfo7" : "itemInfo7",
    "itemInfo6" : "itemInfo6",
    "designatedDayDelivery" : "designatedDayDelivery",
    "rcd" : "rcd",
    "itemInfo5" : "itemInfo5",
    "itemInfo4" : "itemInfo4",
    "itemInfo3" : "itemInfo3",
    "itemInfo2" : "itemInfo2",
    "brand2Name" : "brand2Name",
    "itemInfo1" : "itemInfo1",
    "brand3Name" : "brand3Name",
    "supplyBranchCode" : "supplyBranchCode",
    "catalogRelationId" : "catalogRelationId",
    "itemInfo7Title" : "itemInfo7Title",
    "itemInfo9" : "itemInfo9",
    "greenFlg" : 7,
    "brand1Name" : "brand1Name",
    "lastestPurchaseDate" : "2000-01-23",
    "itemInfo1Title" : "itemInfo1Title",
    "itemInfo11Title" : "itemInfo11Title",
    "standardPrice" : 5,
    "buyerBranchCode" : "buyerBranchCode",
    "categoryCode" : "categoryCode",
    "lClassifiedName" : "lClassifiedName",
    "url" : "url",
    "mClassifiedName" : "mClassifiedName",
    "indexTypeF" : 6,
    "enterNumberName" : "enterNumberName",
    "goodsCategoryName" : "goodsCategoryName",
    "goodsCode" : "goodsCode"
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Suggest
 * サジェスト（検索キーワード）
 *
 * body SuggestRequest サジェスト（検索キーワード）・リクエスト
 * returns SuggestResult
 **/
exports.suggest = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "suggestedTerms" : "{}"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

